#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

size_t maxSeq(int * array, size_t n)
{
  size_t max=1;
  if(array==NULL||n==0)
  return 0;
  for(size_t i=0;i<n-1;i++)
  {
    size_t count=1;
    for(size_t j=i;j<n-1;j++)
    {
      if (*(array+j)<*(array+j+1))
      {
        count++;
      }
      else
      break;
    }
    if(count>max)
    max=count;

  }
  return max;
}

